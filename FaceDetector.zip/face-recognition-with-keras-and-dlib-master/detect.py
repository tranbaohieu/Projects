import sys
from skimage import io
image_path = sys.argv[1]
img = io.imread(image_path)
win = dlib.image_window()
win.clear_overlay()
win.set_image(img)
import dlib
detector = dlib.get_frontal_face_detector() 
dets = detector(img, 1)  
# win.add_overlay(dets) 